// Background service worker
chrome.runtime.onInstalled.addListener(() => {
  console.log('Secure Logout extension installed');
});