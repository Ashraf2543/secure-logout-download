document.addEventListener('DOMContentLoaded', () => {
  const scanBtn = document.getElementById('scanBtn');
  const logoutSelectedBtn = document.getElementById('logoutSelectedBtn');
  const logoutAllBtn = document.getElementById('logoutAllBtn');
  const resultsDiv = document.getElementById('results');
  const statusDiv = document.getElementById('status');
  const searchContainer = document.getElementById('searchContainer');
  const searchInput = document.getElementById('searchInput');
  const clearSearchBtn = document.getElementById('clearSearchBtn');

  let activeLogins = [];
  let allLoginItems = [];

  // Scan for active logins
  scanBtn.addEventListener('click', async () => {
    statusDiv.textContent = 'Scanning for active logins...';
    resultsDiv.innerHTML = '';
    activeLogins = [];
    allLoginItems = [];
    
    try {
      // Get all cookies
      const cookies = await chrome.cookies.getAll({});
      
      // Filter for session cookies (potential logins)
      const sessionCookies = cookies.filter(cookie => {
        return cookie.name.includes('session') || 
               cookie.name.includes('auth') ||
               cookie.name.includes('token') ||
               cookie.name.includes('sess') ||
               cookie.name.includes('login');
      });
      
      // Group by domain
      const domains = new Set();
      sessionCookies.forEach(cookie => {
        const domain = cookie.domain.startsWith('.') ? 
          cookie.domain.substring(1) : cookie.domain;
        domains.add(domain);
      });
      
      // Display results
      if (domains.size === 0) {
        resultsDiv.innerHTML = '<p class="no-results">No active logins found</p>';
        searchContainer.classList.add('hidden');
      } else {
        activeLogins = Array.from(domains);
        searchContainer.classList.remove('hidden');
        
        activeLogins.forEach(domain => {
          const item = document.createElement('div');
          item.className = 'site-item';
          item.dataset.domain = domain;
          item.innerHTML = `
            <div class="site-header">
              <label class="site-name">
                <input type="checkbox" class="site-checkbox" data-domain="${domain}">
                ${domain}
              </label>
              <span class="site-status">Logged in</span>
            </div>
            <div class="site-actions">
              <button class="site-logout-btn" data-domain="${domain}">Logout</button>
            </div>
          `;
          resultsDiv.appendChild(item);
          allLoginItems.push(item);
        });

        // Add event listeners to individual logout buttons
        document.querySelectorAll('.site-logout-btn').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            const domain = e.target.dataset.domain;
            await logoutFromDomain(domain);
            updateUIAfterLogout(domain);
            filterResults(); // Re-filter after logout
          });
        });

        // Add event listeners to checkboxes
        document.querySelectorAll('.site-checkbox').forEach(checkbox => {
          checkbox.addEventListener('change', updateLogoutButtonsState);
        });

        logoutSelectedBtn.disabled = false;
        logoutAllBtn.disabled = false;
      }
      
      statusDiv.textContent = `Found ${domains.size} active logins`;
    } catch (error) {
      statusDiv.textContent = 'Error scanning logins';
      console.error(error);
    }
  });

  // Search functionality
  searchInput.addEventListener('input', filterResults);
  
  clearSearchBtn.addEventListener('click', () => {
    searchInput.value = '';
    filterResults();
  });

  function filterResults() {
    const searchTerm = searchInput.value.toLowerCase();
    let visibleCount = 0;
    
    allLoginItems.forEach(item => {
      const domain = item.dataset.domain.toLowerCase();
      const isVisible = domain.includes(searchTerm);
      
      item.classList.toggle('hidden', !isVisible);
      if (isVisible) visibleCount++;
    });
    
    // Show no results message if nothing matches
    const noResultsMsg = document.querySelector('.no-results');
    if (visibleCount === 0 && allLoginItems.length > 0) {
      if (!noResultsMsg) {
        const msg = document.createElement('p');
        msg.className = 'no-results';
        msg.textContent = 'No websites match your search';
        resultsDiv.appendChild(msg);
      }
    } else if (noResultsMsg) {
      noResultsMsg.remove();
    }
  }

  // Logout from selected sites
  logoutSelectedBtn.addEventListener('click', async () => {
    const selectedDomains = Array.from(document.querySelectorAll('.site-checkbox:checked'))
      .map(checkbox => checkbox.dataset.domain);
    
    if (selectedDomains.length === 0) {
      statusDiv.textContent = 'Please select at least one site';
      return;
    }

    statusDiv.textContent = 'Logging out from selected sites...';
    
    try {
      for (const domain of selectedDomains) {
        await logoutFromDomain(domain);
        updateUIAfterLogout(domain);
      }
      statusDiv.textContent = 'Logged out from selected sites';
      updateLogoutButtonsState();
      filterResults(); // Re-filter after logout
    } catch (error) {
      statusDiv.textContent = 'Error during logout';
      console.error(error);
    }
  });

  // Logout from all sites
  logoutAllBtn.addEventListener('click', async () => {
    statusDiv.textContent = 'Logging out from all sites...';
    
    try {
      for (const domain of activeLogins) {
        await logoutFromDomain(domain);
        updateUIAfterLogout(domain);
      }
      statusDiv.textContent = 'Successfully logged out from all sites';
      logoutSelectedBtn.disabled = true;
      logoutAllBtn.disabled = true;
      searchContainer.classList.add('hidden');
    } catch (error) {
      statusDiv.textContent = 'Error during logout';
      console.error(error);
    }
  });

  // Helper function to logout from a specific domain
  async function logoutFromDomain(domain) {
    // Clear cookies for the domain
    const cookies = await chrome.cookies.getAll({ domain });
    for (const cookie of cookies) {
      const url = `http${cookie.secure ? 's' : ''}://${cookie.domain}${cookie.path}`;
      await chrome.cookies.remove({ url, name: cookie.name });
    }

    // Close tabs with this domain
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (tab.url && tab.url.includes(domain)) {
        await chrome.tabs.remove(tab.id);
      }
    }
  }

  // Helper function to update UI after logout
  function updateUIAfterLogout(domain) {
    const item = document.querySelector(`.site-item[data-domain="${domain}"]`);
    if (item) {
      item.querySelector('.site-status').textContent = 'Logged out';
      item.querySelector('.site-logout-btn').disabled = true;
      item.querySelector('.site-checkbox').disabled = true;
    }
  }

  // Helper function to update logout buttons state
  function updateLogoutButtonsState() {
    const anyChecked = Array.from(document.querySelectorAll('.site-checkbox:not(:disabled)')).some(cb => cb.checked);
    logoutSelectedBtn.disabled = !anyChecked;
  }
});